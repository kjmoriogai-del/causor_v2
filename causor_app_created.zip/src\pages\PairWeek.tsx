import { useState } from 'react'
import { useData } from '../contexts/DataContext'
import { format, isSameWeek, startOfWeek } from 'date-fns'
import ko from 'date-fns/locale/ko'
import './PairWeek.css'

const PairWeek = () => {
  const { events } = useData()
  const now = new Date()
  const weekStart = startOfWeek(now, { locale: ko })
  
  // 이번 주 이벤트 필터링
  const thisWeekEvents = events.filter(event => 
    isSameWeek(event.date, now, { locale: ko })
  )

  const [selectedEvent, setSelectedEvent] = useState<string | null>(null)

  const eventTypes = {
    meal: '🍽️ 밥약',
    mentoring: '👥 멘토링',
    study: '📚 스터디',
    activity: '🎯 활동',
    other: '📌 기타'
  }

  return (
    <div className="pair-week-page">
      <div className="page-header">
        <h2>Pair Week</h2>
        <p>이번 주 리더들이 계획한 소규모 만남</p>
        <div className="week-info">
          {format(weekStart, 'yyyy년 M월 d일', { locale: ko })} ~ {format(new Date(weekStart.getTime() + 6 * 24 * 60 * 60 * 1000), 'M월 d일', { locale: ko })}
        </div>
      </div>

      {thisWeekEvents.length === 0 ? (
        <div className="empty-state">
          <p>이번 주 예정된 이벤트가 없습니다.</p>
          <p>곧 새로운 이벤트가 등록될 예정입니다!</p>
        </div>
      ) : (
        <div className="events-list">
          {thisWeekEvents.map(event => (
            <div 
              key={event.id} 
              className={`event-card ${selectedEvent === event.id ? 'expanded' : ''}`}
              onClick={() => setSelectedEvent(selectedEvent === event.id ? null : event.id)}
            >
              <div className="event-header">
                <div className="event-type-badge">
                  {eventTypes[event.type]}
                </div>
                <div className="event-title-section">
                  <h3>{event.title}</h3>
                  <p className="event-leader">리더: {event.leaderName}</p>
                </div>
                <div className="event-meta">
                  <span className="event-date">
                    {format(event.date, 'M월 d일 (EEE)', { locale: ko })}
                  </span>
                  <span className="event-time">{event.time}</span>
                </div>
              </div>

              {selectedEvent === event.id && (
                <div className="event-details">
                  <div className="detail-row">
                    <span className="detail-label">📍 장소</span>
                    <span className="detail-value">{event.location}</span>
                  </div>
                  <div className="detail-row">
                    <span className="detail-label">📝 설명</span>
                    <span className="detail-value">{event.description}</span>
                  </div>
                  <div className="detail-row">
                    <span className="detail-label">👥 참가자</span>
                    <span className="detail-value">
                      {event.participants}명
                      {event.maxParticipants && ` / ${event.maxParticipants}명`}
                    </span>
                  </div>
                  {event.maxParticipants && event.participants < event.maxParticipants && (
                    <button className="join-button">
                      참가 신청하기
                    </button>
                  )}
                  {event.maxParticipants && event.participants >= event.maxParticipants && (
                    <button className="join-button disabled" disabled>
                      모집 마감
                    </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default PairWeek

