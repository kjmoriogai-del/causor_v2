import { ReactNode } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import './Layout.css'

interface LayoutProps {
  children: ReactNode
}

const Layout = ({ children }: LayoutProps) => {
  const location = useLocation()
  const { currentUser, switchRole, isLeader } = useAuth()

  return (
    <div className="layout">
      <header className="header">
        <h1 className="logo">학생 연결 앱</h1>
        <p className="subtitle">유학생과 재학생 네트워크</p>
      </header>
      
      <nav className="navbar">
        <Link 
          to="/" 
          className={location.pathname === '/' ? 'nav-link active' : 'nav-link'}
        >
          홈
        </Link>
        <Link 
          to="/leaders" 
          className={location.pathname === '/leaders' ? 'nav-link active' : 'nav-link'}
        >
          리더 소개
        </Link>
        <Link 
          to="/pair-week" 
          className={location.pathname === '/pair-week' ? 'nav-link active' : 'nav-link'}
        >
          Pair Week
        </Link>
        <Link 
          to="/calendar" 
          className={location.pathname === '/calendar' ? 'nav-link active' : 'nav-link'}
        >
          캘린더
        </Link>
        <Link 
          to="/profile" 
          className={location.pathname === '/profile' ? 'nav-link active' : 'nav-link'}
        >
          프로필
        </Link>
        {isLeader && (
          <Link 
            to="/admin" 
            className={location.pathname === '/admin' ? 'nav-link active' : 'nav-link'}
          >
            관리자
          </Link>
        )}
      </nav>

      <div className="role-toggle">
        <span>
          현재 역할: <strong>{isLeader ? '운영 리더' : '일반 사용자'}</strong>
        </span>
        <div className="role-buttons">
          <button
            type="button"
            className={currentUser.role === 'general' ? 'active' : ''}
            onClick={() => switchRole('general')}
          >
            일반 사용자
          </button>
          <button
            type="button"
            className={currentUser.role === 'leader' ? 'active' : ''}
            onClick={() => switchRole('leader')}
          >
            운영 리더
          </button>
        </div>
      </div>

      <main className="main-content">
        {children}
      </main>
    </div>
  )
}

export default Layout

