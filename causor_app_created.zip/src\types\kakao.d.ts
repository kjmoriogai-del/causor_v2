declare global {
  interface Window {
    kakao: any
  }

  const kakao: any
}

export {}

