# 학생 연결 앱

유학생과 한국인 재학생을 연결하는 네트워크 플랫폼 웹앱입니다.

## 주요 기능

1. **홈 화면**: 이번 달/다음 달 예정된 이벤트 홍보 배너
2. **리더 소개**: 한국인 및 유학생 리더들의 상세 정보 확인
3. **Pair Week**: 이번 주 소규모 행사 정보
4. **캘린더**: 월별 이벤트 일정 확인 및 상세 정보 보기
5. **프로필**: 사용자 정보 및 참가/진행한 이벤트 관리

## 기술 스택

- React 18
- TypeScript
- React Router
- Vite
- date-fns

## 설치 및 실행

```bash
# 의존성 설치
npm install

# 개발 서버 실행
npm run dev

# 프로덕션 빌드
npm run build

# 빌드 미리보기
npm run preview
```

## 프로젝트 구조

```
src/
  ├── components/     # 공통 컴포넌트
  ├── pages/          # 페이지 컴포넌트
  ├── types/          # TypeScript 타입 정의
  ├── data/           # 목업 데이터
  └── App.tsx         # 메인 앱 컴포넌트
```

## API 연동 설정

이 앱은 다음 데이터 소스를 지원합니다:

1. **Mock 데이터** (기본값): 로컬 mockData 사용
2. **구글 시트**: 구글 시트에서 실시간 데이터 가져오기
3. **REST API**: 외부 API 서버에서 데이터 가져오기

### 환경 변수 설정

프로젝트 루트에 `.env` 파일을 생성하고 다음 변수를 설정하세요:

```env
# 데이터 소스 선택: 'mock' | 'google-sheets' | 'api'
VITE_DATA_SOURCE=mock

# REST API 사용 시
VITE_API_BASE_URL=http://localhost:3000

# 구글 시트 사용 시
VITE_GOOGLE_SHEETS_API_KEY=your_api_key_here
VITE_GOOGLE_SHEETS_ID=your_sheet_id_here
```

### 구글 시트 연동

1. 구글 시트를 생성하고 공개로 설정
2. 시트 이름을 "Events"와 "Leaders"로 설정
3. 각 시트의 첫 번째 행에 헤더 추가:
   - Events: id, title, description, date, time, location, type, leaderId, leaderName, participants, maxParticipants, image
   - Leaders: id, name, age, nationality, photo, shortDescription, detailedDescription, hobbies, strengths, eventsHosted, recentActivity
4. Google Sheets API 키 발급 및 `.env` 파일에 설정

### REST API 연동

REST API를 사용하려면 다음 엔드포인트를 제공해야 합니다:

- `GET /api/events` - 이벤트 목록 반환
- `GET /api/leaders` - 리더 목록 반환

응답 형식은 TypeScript 타입 정의(`src/types/index.ts`)를 참고하세요.

## 개발 계획서 기반 구현

이 앱은 개발 계획서에 명시된 다음 요구사항을 구현했습니다:

- ✅ 이번 달/다음 달 이벤트 홍보 배너
- ✅ 리더 소개 (한국인/유학생 구분, 최근 활동 리더 표시)
- ✅ Pair Week (이번 주 소규모 행사)
- ✅ 캘린더 (월별 이벤트 일정)
- ✅ 프로필 (진행/참가한 이벤트 관리)
- ✅ 관리자 페이지 (이벤트/리더 관리)
- ✅ API 연동 지원 (구글 시트, REST API)

