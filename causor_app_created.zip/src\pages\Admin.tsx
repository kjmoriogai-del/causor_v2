import { useState } from 'react'
import { useData } from '../contexts/DataContext'
import { Event, Leader } from '../types'
import { format } from 'date-fns'
import ko from 'date-fns/locale/ko'
import './Admin.css'
import { useAuth } from '../contexts/AuthContext'

const Admin = () => {
  const { isLeader } = useAuth()
  const { events, leaders, updateEvent, addEvent, deleteEvent, updateLeader, addLeader, deleteLeader, refreshData, isLoading } = useData()
  const [activeTab, setActiveTab] = useState<'events' | 'leaders'>('events')
  const [editingEvent, setEditingEvent] = useState<Event | null>(null)
  const [editingLeader, setEditingLeader] = useState<Leader | null>(null)
  const [showEventForm, setShowEventForm] = useState(false)
  const [showLeaderForm, setShowLeaderForm] = useState(false)

  const eventTypes = {
    meal: '🍽️ 밥약',
    mentoring: '👥 멘토링',
    study: '📚 스터디',
    activity: '🎯 활동',
    other: '📌 기타'
  }

  const handleDeleteEvent = (id: string) => {
    if (confirm('이 이벤트를 삭제하시겠습니까?')) {
      deleteEvent(id)
    }
  }

  const handleDeleteLeader = (id: string) => {
    if (confirm('이 리더를 삭제하시겠습니까?')) {
      deleteLeader(id)
    }
  }

  const handleEditEvent = (event: Event) => {
    setEditingEvent({ ...event })
    setShowEventForm(true)
  }

  const handleEditLeader = (leader: Leader) => {
    setEditingLeader({ ...leader })
    setShowLeaderForm(true)
  }

  const handleSaveEvent = (eventData: Partial<Event>) => {
    if (editingEvent) {
      updateEvent(editingEvent.id, eventData)
    } else {
      const newEvent: Event = {
        id: Date.now().toString(),
        title: eventData.title || '',
        description: eventData.description || '',
        date: eventData.date || new Date(),
        time: eventData.time || '',
        location: eventData.location || '',
        type: eventData.type || 'other',
        leaderId: eventData.leaderId || '',
        leaderName: eventData.leaderName || '',
        participants: eventData.participants || 0,
        maxParticipants: eventData.maxParticipants,
        image: eventData.image
      }
      addEvent(newEvent)
    }
    setShowEventForm(false)
    setEditingEvent(null)
  }

  const handleSaveLeader = (leaderData: Partial<Leader>) => {
    if (editingLeader) {
      updateLeader(editingLeader.id, leaderData)
    } else {
      const newLeader: Leader = {
        id: Date.now().toString(),
        name: leaderData.name || '',
        age: leaderData.age || 0,
        nationality: leaderData.nationality || 'korean',
        photo: leaderData.photo || '',
        shortDescription: leaderData.shortDescription || '',
        detailedDescription: leaderData.detailedDescription || '',
        hobbies: leaderData.hobbies || [],
        strengths: leaderData.strengths || [],
        eventsHosted: leaderData.eventsHosted || 0,
        recentActivity: leaderData.recentActivity
      }
      addLeader(newLeader)
    }
    setShowLeaderForm(false)
    setEditingLeader(null)
  }

  if (!isLeader) {
    return (
      <div className="admin-page">
        <div className="admin-notice">
          <p>이 페이지는 운영 리더만 접근할 수 있습니다.</p>
          <p>권한이 필요하면 관리자에게 문의하세요.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="admin-page">
      <div className="admin-header">
        <div>
          <h1>관리자 페이지</h1>
          <p>이벤트와 리더를 관리할 수 있습니다</p>
        </div>
        <button 
          className="btn-secondary" 
          onClick={refreshData}
          disabled={isLoading}
        >
          {isLoading ? '로딩 중...' : '🔄 데이터 새로고침'}
        </button>
      </div>

      <div className="admin-tabs">
        <button
          className={activeTab === 'events' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('events')}
        >
          이벤트 관리
        </button>
        <button
          className={activeTab === 'leaders' ? 'tab active' : 'tab'}
          onClick={() => setActiveTab('leaders')}
        >
          리더 관리
        </button>
      </div>

      {activeTab === 'events' && (
        <div className="admin-content">
          <div className="admin-actions">
            <button className="btn-primary" onClick={() => {
              setEditingEvent(null)
              setShowEventForm(true)
            }}>
              + 새 이벤트 추가
            </button>
          </div>

          <div className="admin-table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>제목</th>
                  <th>날짜</th>
                  <th>시간</th>
                  <th>장소</th>
                  <th>타입</th>
                  <th>리더</th>
                  <th>참가자</th>
                  <th>작업</th>
                </tr>
              </thead>
              <tbody>
                {events.map(event => (
                  <tr key={event.id}>
                    <td>{event.title}</td>
                    <td>{format(event.date, 'yyyy-MM-dd', { locale: ko })}</td>
                    <td>{event.time}</td>
                    <td>{event.location}</td>
                    <td>{eventTypes[event.type]}</td>
                    <td>{event.leaderName}</td>
                    <td>{event.participants}{event.maxParticipants ? ` / ${event.maxParticipants}` : ''}</td>
                    <td>
                      <button className="btn-edit" onClick={() => handleEditEvent(event)}>수정</button>
                      <button className="btn-delete" onClick={() => handleDeleteEvent(event.id)}>삭제</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {showEventForm && (
            <EventForm
              event={editingEvent}
              leaders={leaders}
              onSave={handleSaveEvent}
              onCancel={() => {
                setShowEventForm(false)
                setEditingEvent(null)
              }}
            />
          )}
        </div>
      )}

      {activeTab === 'leaders' && (
        <div className="admin-content">
          <div className="admin-actions">
            <button className="btn-primary" onClick={() => {
              setEditingLeader(null)
              setShowLeaderForm(true)
            }}>
              + 새 리더 추가
            </button>
          </div>

          <div className="admin-table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>이름</th>
                  <th>나이</th>
                  <th>국적</th>
                  <th>한줄 설명</th>
                  <th>진행 이벤트</th>
                  <th>작업</th>
                </tr>
              </thead>
              <tbody>
                {leaders.map(leader => (
                  <tr key={leader.id}>
                    <td>{leader.name}</td>
                    <td>{leader.age}</td>
                    <td>{leader.nationality === 'korean' ? '한국인' : '유학생'}</td>
                    <td>{leader.shortDescription}</td>
                    <td>{leader.eventsHosted}개</td>
                    <td>
                      <button className="btn-edit" onClick={() => handleEditLeader(leader)}>수정</button>
                      <button className="btn-delete" onClick={() => handleDeleteLeader(leader.id)}>삭제</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {showLeaderForm && (
            <LeaderForm
              leader={editingLeader}
              onSave={handleSaveLeader}
              onCancel={() => {
                setShowLeaderForm(false)
                setEditingLeader(null)
              }}
            />
          )}
        </div>
      )}
    </div>
  )
}

interface EventFormProps {
  event: Event | null
  leaders: Leader[]
  onSave: (data: Partial<Event>) => void
  onCancel: () => void
}

const EventForm = ({ event, leaders, onSave, onCancel }: EventFormProps) => {
  const [formData, setFormData] = useState<Partial<Event>>({
    title: event?.title || '',
    description: event?.description || '',
    date: event?.date ? format(event.date, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
    time: event?.time || '',
    location: event?.location || '',
    type: event?.type || 'other',
    leaderId: event?.leaderId || '',
    leaderName: event?.leaderName || '',
    participants: event?.participants || 0,
    maxParticipants: event?.maxParticipants || undefined,
    image: event?.image || ''
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const selectedLeader = leaders.find(l => l.id === formData.leaderId)
    onSave({
      ...formData,
      date: new Date(formData.date as string),
      leaderName: selectedLeader?.name || formData.leaderName
    })
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content admin-form">
        <h2>{event ? '이벤트 수정' : '새 이벤트 추가'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>제목</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>설명</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              required
            />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>날짜</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>시간</label>
              <input
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                required
              />
            </div>
          </div>
          <div className="form-group">
            <label>장소</label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              required
            />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>타입</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as Event['type'] })}
                required
              >
                <option value="meal">밥약</option>
                <option value="mentoring">멘토링</option>
                <option value="study">스터디</option>
                <option value="activity">활동</option>
                <option value="other">기타</option>
              </select>
            </div>
            <div className="form-group">
              <label>리더</label>
              <select
                value={formData.leaderId}
                onChange={(e) => {
                  const leader = leaders.find(l => l.id === e.target.value)
                  setFormData({
                    ...formData,
                    leaderId: e.target.value,
                    leaderName: leader?.name || ''
                  })
                }}
                required
              >
                <option value="">선택하세요</option>
                {leaders.map(leader => (
                  <option key={leader.id} value={leader.id}>{leader.name}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>참가자 수</label>
              <input
                type="number"
                value={formData.participants}
                onChange={(e) => setFormData({ ...formData, participants: parseInt(e.target.value) || 0 })}
                min="0"
              />
            </div>
            <div className="form-group">
              <label>최대 참가자 수</label>
              <input
                type="number"
                value={formData.maxParticipants || ''}
                onChange={(e) => setFormData({ ...formData, maxParticipants: parseInt(e.target.value) || undefined })}
                min="0"
              />
            </div>
          </div>
          <div className="form-group">
            <label>이미지 URL (선택)</label>
            <input
              type="url"
              value={formData.image || ''}
              onChange={(e) => setFormData({ ...formData, image: e.target.value })}
            />
          </div>
          <div className="form-actions">
            <button type="submit" className="btn-primary">저장</button>
            <button type="button" className="btn-secondary" onClick={onCancel}>취소</button>
          </div>
        </form>
      </div>
    </div>
  )
}

interface LeaderFormProps {
  leader: Leader | null
  onSave: (data: Partial<Leader>) => void
  onCancel: () => void
}

const LeaderForm = ({ leader, onSave, onCancel }: LeaderFormProps) => {
  const [formData, setFormData] = useState<Partial<Leader>>({
    name: leader?.name || '',
    age: leader?.age || 0,
    nationality: leader?.nationality || 'korean',
    photo: leader?.photo || '',
    shortDescription: leader?.shortDescription || '',
    detailedDescription: leader?.detailedDescription || '',
    hobbies: leader?.hobbies || [],
    strengths: leader?.strengths || [],
    eventsHosted: leader?.eventsHosted || 0,
    recentActivity: leader?.recentActivity || false
  })

  const [hobbyInput, setHobbyInput] = useState('')
  const [strengthInput, setStrengthInput] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
  }

  const addHobby = () => {
    if (hobbyInput.trim()) {
      setFormData({
        ...formData,
        hobbies: [...(formData.hobbies || []), hobbyInput.trim()]
      })
      setHobbyInput('')
    }
  }

  const removeHobby = (index: number) => {
    setFormData({
      ...formData,
      hobbies: formData.hobbies?.filter((_, i) => i !== index) || []
    })
  }

  const addStrength = () => {
    if (strengthInput.trim()) {
      setFormData({
        ...formData,
        strengths: [...(formData.strengths || []), strengthInput.trim()]
      })
      setStrengthInput('')
    }
  }

  const removeStrength = (index: number) => {
    setFormData({
      ...formData,
      strengths: formData.strengths?.filter((_, i) => i !== index) || []
    })
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content admin-form">
        <h2>{leader ? '리더 수정' : '새 리더 추가'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group">
              <label>이름</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>나이</label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) || 0 })}
                min="0"
                required
              />
            </div>
          </div>
          <div className="form-group">
            <label>국적</label>
            <select
              value={formData.nationality}
              onChange={(e) => setFormData({ ...formData, nationality: e.target.value as Leader['nationality'] })}
              required
            >
              <option value="korean">한국인</option>
              <option value="international">유학생</option>
            </select>
          </div>
          <div className="form-group">
            <label>사진 URL</label>
            <input
              type="url"
              value={formData.photo}
              onChange={(e) => setFormData({ ...formData, photo: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>한줄 설명</label>
            <input
              type="text"
              value={formData.shortDescription}
              onChange={(e) => setFormData({ ...formData, shortDescription: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>상세 설명</label>
            <textarea
              value={formData.detailedDescription}
              onChange={(e) => setFormData({ ...formData, detailedDescription: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>취미</label>
            <div className="tag-input">
              <input
                type="text"
                value={hobbyInput}
                onChange={(e) => setHobbyInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addHobby())}
                placeholder="취미를 입력하고 Enter"
              />
              <button type="button" onClick={addHobby}>추가</button>
            </div>
            <div className="tags">
              {formData.hobbies?.map((hobby, index) => (
                <span key={index} className="tag">
                  {hobby}
                  <button type="button" onClick={() => removeHobby(index)}>×</button>
                </span>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label>장점</label>
            <div className="tag-input">
              <input
                type="text"
                value={strengthInput}
                onChange={(e) => setStrengthInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addStrength())}
                placeholder="장점을 입력하고 Enter"
              />
              <button type="button" onClick={addStrength}>추가</button>
            </div>
            <div className="tags">
              {formData.strengths?.map((strength, index) => (
                <span key={index} className="tag">
                  {strength}
                  <button type="button" onClick={() => removeStrength(index)}>×</button>
                </span>
              ))}
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>진행한 이벤트 수</label>
              <input
                type="number"
                value={formData.eventsHosted}
                onChange={(e) => setFormData({ ...formData, eventsHosted: parseInt(e.target.value) || 0 })}
                min="0"
              />
            </div>
            <div className="form-group">
              <label>
                <input
                  type="checkbox"
                  checked={formData.recentActivity}
                  onChange={(e) => setFormData({ ...formData, recentActivity: e.target.checked })}
                />
                최근 활동
              </label>
            </div>
          </div>
          <div className="form-actions">
            <button type="submit" className="btn-primary">저장</button>
            <button type="button" className="btn-secondary" onClick={onCancel}>취소</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default Admin

