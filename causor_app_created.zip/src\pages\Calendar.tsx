import { useState, useEffect, useRef } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useData } from '../contexts/DataContext'
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths } from 'date-fns'
import ko from 'date-fns/locale/ko'
import { Event } from '../types'
import './Calendar.css'

// localStorage에서 참가한 이벤트 목록 가져오기
const getJoinedEvents = (): string[] => {
  try {
    const stored = localStorage.getItem('student-connection-joined-events')
    return stored ? JSON.parse(stored) : []
  } catch {
    return []
  }
}

// localStorage에 참가한 이벤트 목록 저장
const saveJoinedEvents = (eventIds: string[]): void => {
  try {
    localStorage.setItem('student-connection-joined-events', JSON.stringify(eventIds))
  } catch (error) {
    console.error('참가 이벤트 저장 중 오류:', error)
  }
}

let kakaoLoadPromise: Promise<void> | null = null

const waitForKakaoMaps = (): Promise<void> => {
  if (window.kakao && window.kakao.maps) {
    return Promise.resolve()
  }

  if (!kakaoLoadPromise) {
    kakaoLoadPromise = new Promise<void>((resolve, reject) => {
      const script = document.getElementById('kakao-map-script') as HTMLScriptElement | null
      if (!script) {
        reject(new Error('카카오 지도 스크립트를 찾을 수 없습니다.'))
        return
      }

      const onLoad = () => {
        if (window.kakao && window.kakao.maps) {
          resolve()
        } else {
          reject(new Error('카카오 지도 객체를 초기화할 수 없습니다.'))
        }
      }

      const scriptReadyState = (script as HTMLScriptElement & { readyState?: string }).readyState

      if (script.getAttribute('data-loaded') === 'true' || scriptReadyState === 'complete' || scriptReadyState === 'loaded') {
        onLoad()
        return
      }

      script.addEventListener('load', () => {
        script.setAttribute('data-loaded', 'true')
        onLoad()
      })

      script.addEventListener('error', () => {
        reject(new Error('카카오 지도 스크립트를 불러올 수 없습니다.'))
      })
    })
  }

  return kakaoLoadPromise
}

const Calendar = () => {
  const { events, updateEvent } = useData()
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null)
  const [joinedEvents, setJoinedEvents] = useState<string[]>(getJoinedEvents())
  const [searchParams, setSearchParams] = useSearchParams()

  // 참가 신청
  const handleJoin = (eventId: string) => {
    const event = events.find(e => e.id === eventId)
    if (event) {
      // maxParticipants가 없거나 아직 여유가 있는 경우
      if (!event.maxParticipants || event.participants < event.maxParticipants) {
        const newParticipants = event.participants + 1
        updateEvent(eventId, { participants: newParticipants })
        
        // 참가한 이벤트 목록에 추가
        const newJoinedEvents = [...joinedEvents, eventId]
        setJoinedEvents(newJoinedEvents)
        saveJoinedEvents(newJoinedEvents)
        
        // 모달의 이벤트도 즉시 업데이트
        const updatedEvent = { ...event, participants: newParticipants }
        setSelectedEvent(updatedEvent)
      }
    }
  }

  // 참가 취소
  const handleCancel = (eventId: string) => {
    const event = events.find(e => e.id === eventId)
    if (event && event.participants > 0) {
      const newParticipants = Math.max(0, event.participants - 1)
      updateEvent(eventId, { participants: newParticipants })
      
      // 참가한 이벤트 목록에서 제거
      const newJoinedEvents = joinedEvents.filter(id => id !== eventId)
      setJoinedEvents(newJoinedEvents)
      saveJoinedEvents(newJoinedEvents)
      
      // 모달의 이벤트도 즉시 업데이트
      const updatedEvent = { ...event, participants: newParticipants }
      setSelectedEvent(updatedEvent)
    }
  }

  // URL에서 event ID가 있으면 해당 이벤트 표시
  const eventIdFromUrl = searchParams.get('event')
  useEffect(() => {
    if (eventIdFromUrl && !selectedEvent) {
      const event = events.find(e => e.id === eventIdFromUrl)
      if (event) {
        setSelectedEvent(event)
        setSearchParams({})
      }
    }
  }, [eventIdFromUrl, events, selectedEvent])

  const monthStart = startOfMonth(currentDate)
  const monthEnd = endOfMonth(currentDate)
  const calendarStart = startOfWeek(monthStart, { locale: ko })
  const calendarEnd = endOfWeek(monthEnd, { locale: ko })
  
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd })

  // 다음 달 이벤트 필터링
  const nextMonthEvents = events.filter(event => 
    isSameMonth(event.date, addMonths(currentDate, 1))
  )

  const getEventsForDay = (day: Date) => {
    return events.filter(event => isSameDay(event.date, day))
  }

  const eventTypes = {
    meal: '🍽️',
    mentoring: '👥',
    study: '📚',
    activity: '🎯',
    other: '📌'
  }

  const goToPreviousMonth = () => {
    setCurrentDate(subMonths(currentDate, 1))
  }

  const goToNextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1))
  }

  return (
    <div className="calendar-page">
      <div className="page-header">
        <h2>이벤트 캘린더</h2>
        <p>예정된 행사 일정을 확인하세요</p>
      </div>

      <div className="calendar-controls">
        <button onClick={goToPreviousMonth} className="month-nav">‹</button>
        <h3 className="current-month">
          {format(currentDate, 'yyyy년 M월', { locale: ko })}
        </h3>
        <button onClick={goToNextMonth} className="month-nav">›</button>
      </div>

      <div className="calendar-container">
        <div className="calendar-grid">
          <div className="calendar-weekday">일</div>
          <div className="calendar-weekday">월</div>
          <div className="calendar-weekday">화</div>
          <div className="calendar-weekday">수</div>
          <div className="calendar-weekday">목</div>
          <div className="calendar-weekday">금</div>
          <div className="calendar-weekday">토</div>

          {days.map((day, index) => {
            const dayEvents = getEventsForDay(day)
            const isCurrentMonth = isSameMonth(day, currentDate)
            const isToday = isSameDay(day, new Date())

            return (
              <div
                key={index}
                className={`calendar-day ${!isCurrentMonth ? 'other-month' : ''} ${isToday ? 'today' : ''}`}
              >
                <div className="day-number">{format(day, 'd')}</div>
                <div className="day-events">
                  {dayEvents.slice(0, 3).map(event => (
                    <div
                      key={event.id}
                      className="event-indicator"
                      onClick={(e) => {
                        e.stopPropagation()
                        setSelectedEvent(event)
                      }}
                      title={event.title}
                    >
                      {eventTypes[event.type]} {event.title}
                    </div>
                  ))}
                  {dayEvents.length > 3 && (
                    <div className="more-events">+{dayEvents.length - 3}개 더</div>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      <div className="upcoming-events-section">
        <h3>다음 달 예정 이벤트</h3>
        {nextMonthEvents.length === 0 ? (
          <p className="no-events">다음 달 예정된 이벤트가 없습니다.</p>
        ) : (
          <div className="events-preview">
            {nextMonthEvents.map(event => (
              <div
                key={event.id}
                className="event-preview-card"
                onClick={() => setSelectedEvent(event)}
              >
                <span className="preview-date">
                  {format(event.date, 'M월 d일', { locale: ko })}
                </span>
                <span className="preview-title">{event.title}</span>
                <span className="preview-type">{eventTypes[event.type]}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedEvent && (
        <EventModal 
          event={selectedEvent} 
          onClose={() => setSelectedEvent(null)}
          onJoin={handleJoin}
          onCancel={handleCancel}
          isJoined={joinedEvents.includes(selectedEvent.id)}
        />
      )}
    </div>
  )
}

interface EventModalProps {
  event: Event
  onClose: () => void
  onJoin: (eventId: string) => void
  onCancel: (eventId: string) => void
  isJoined: boolean
}

const EventModal = ({ event, onClose, onJoin, onCancel, isJoined }: EventModalProps) => {
  const [showMap, setShowMap] = useState(false)
  const [isMapLoading, setIsMapLoading] = useState(false)
  const [mapError, setMapError] = useState<string | null>(null)
  const mapRef = useRef<HTMLDivElement>(null)

  const renderMap = async () => {
    if (!mapRef.current) return

    setIsMapLoading(true)
    try {
      await waitForKakaoMaps()

      window.kakao.maps.load(() => {
        const geocoder = new window.kakao.maps.services.Geocoder()
        geocoder.addressSearch(event.location, (result: any[], status: any) => {
          if (status === window.kakao.maps.services.Status.OK) {
            const coords = new window.kakao.maps.LatLng(Number(result[0].y), Number(result[0].x))
            const map = new window.kakao.maps.Map(mapRef.current as HTMLElement, {
              center: coords,
              level: 3
            })
            new window.kakao.maps.Marker({
              map,
              position: coords
            })
            setMapError(null)
          } else {
            setMapError('해당 주소를 찾을 수 없습니다.')
          }
          setIsMapLoading(false)
        })
      })
    } catch (error) {
      console.error(error)
      setMapError('지도를 불러올 수 없습니다.')
      setIsMapLoading(false)
    }
  }

  useEffect(() => {
    if (showMap) {
      renderMap()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showMap, event.id])

  useEffect(() => {
    setShowMap(false)
    setMapError(null)
  }, [event.id])
  const eventTypes = {
    meal: '🍽️ 밥약',
    mentoring: '👥 멘토링',
    study: '📚 스터디',
    activity: '🎯 활동',
    other: '📌 기타'
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>×</button>
        {event.image && (
          <img src={event.image} alt={event.title} className="modal-event-image" />
        )}
        <div className="modal-event-header">
          <div className="event-type-badge-large">
            {eventTypes[event.type]}
          </div>
          <h2>{event.title}</h2>
          <p className="event-leader-name">리더: {event.leaderName}</p>
          <button
            className="location-button"
            onClick={() => setShowMap((prev) => !prev)}
          >
            {showMap ? '지도 닫기' : '위치 보기'}
          </button>
        </div>
        <div className="modal-event-body">
          <div className="event-info-grid">
            <div className="info-item">
              <span className="info-icon">📅</span>
              <div>
                <div className="info-label">날짜</div>
                <div className="info-value">
                  {format(event.date, 'yyyy년 M월 d일 (EEE)', { locale: ko })}
                </div>
              </div>
            </div>
            <div className="info-item">
              <span className="info-icon">🕐</span>
              <div>
                <div className="info-label">시간</div>
                <div className="info-value">{event.time}</div>
              </div>
            </div>
            <div className="info-item">
              <span className="info-icon">📍</span>
              <div>
                <div className="info-label">장소</div>
                <div className="info-value">{event.location}</div>
              </div>
            </div>
            <div className="info-item">
              <span className="info-icon">👥</span>
              <div>
                <div className="info-label">참가자</div>
                <div className="info-value">
                  {event.participants}명
                  {event.maxParticipants && ` / ${event.maxParticipants}명`}
                </div>
              </div>
            </div>
          </div>
          <div className="event-description">
            <h3>설명</h3>
            <p>{event.description}</p>
          </div>
          {showMap && (
            <div className="map-section">
              {isMapLoading && <p className="map-status">지도를 불러오는 중입니다...</p>}
              {mapError && <p className="map-status error">{mapError}</p>}
              <div ref={mapRef} className={`kakao-map ${mapError ? 'hidden' : ''}`}></div>
            </div>
          )}
          {isJoined ? (
            <button 
              className="join-button-large cancel"
              onClick={() => onCancel(event.id)}
            >
              참가 취소
            </button>
          ) : (
            <>
              {event.maxParticipants && event.participants < event.maxParticipants && (
                <button 
                  className="join-button-large"
                  onClick={() => onJoin(event.id)}
                >
                  참가 신청하기
                </button>
              )}
              {event.maxParticipants && event.participants >= event.maxParticipants && (
                <button className="join-button-large disabled" disabled>
                  모집 마감
                </button>
              )}
              {!event.maxParticipants && (
                <button 
                  className="join-button-large"
                  onClick={() => onJoin(event.id)}
                >
                  참가 신청하기
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default Calendar

