import { Event, Leader } from '../types'

// API 설정
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || ''
const GOOGLE_SHEETS_API_KEY = import.meta.env.VITE_GOOGLE_SHEETS_API_KEY || ''
const GOOGLE_SHEETS_ID = import.meta.env.VITE_GOOGLE_SHEETS_ID || ''

// 구글 시트에서 데이터 가져오기
export const fetchEventsFromGoogleSheets = async (): Promise<Event[]> => {
  if (!GOOGLE_SHEETS_ID) {
    console.warn('Google Sheets ID가 설정되지 않았습니다.')
    return []
  }

  try {
    // 구글 시트 공개 URL 또는 API 사용
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${GOOGLE_SHEETS_ID}/values/Events?key=${GOOGLE_SHEETS_API_KEY}`
    
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error('구글 시트 데이터를 가져오는데 실패했습니다.')
    }

    const data = await response.json()
    const rows = data.values || []

    // 첫 번째 행은 헤더이므로 제외
    return rows.slice(1).map((row: any[], index: number) => {
      return {
        id: row[0] || `event-${index}`,
        title: row[1] || '',
        description: row[2] || '',
        date: new Date(row[3] || new Date()),
        time: row[4] || '',
        location: row[5] || '',
        type: (row[6] || 'other') as Event['type'],
        leaderId: row[7] || '',
        leaderName: row[8] || '',
        participants: parseInt(row[9] || '0'),
        maxParticipants: row[10] ? parseInt(row[10]) : undefined,
        image: row[11] || undefined
      } as Event
    })
  } catch (error) {
    console.error('구글 시트에서 이벤트를 가져오는 중 오류:', error)
    return []
  }
}

export const fetchLeadersFromGoogleSheets = async (): Promise<Leader[]> => {
  if (!GOOGLE_SHEETS_ID) {
    console.warn('Google Sheets ID가 설정되지 않았습니다.')
    return []
  }

  try {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${GOOGLE_SHEETS_ID}/values/Leaders?key=${GOOGLE_SHEETS_API_KEY}`
    
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error('구글 시트 데이터를 가져오는데 실패했습니다.')
    }

    const data = await response.json()
    const rows = data.values || []

    return rows.slice(1).map((row: any[], index: number) => {
      return {
        id: row[0] || `leader-${index}`,
        name: row[1] || '',
        age: parseInt(row[2] || '0'),
        nationality: (row[3] || 'korean') as Leader['nationality'],
        photo: row[4] || '',
        shortDescription: row[5] || '',
        detailedDescription: row[6] || '',
        hobbies: row[7] ? row[7].split(',').map((h: string) => h.trim()) : [],
        strengths: row[8] ? row[8].split(',').map((s: string) => s.trim()) : [],
        eventsHosted: parseInt(row[9] || '0'),
        recentActivity: row[10] === 'true' || row[10] === 'TRUE'
      } as Leader
    })
  } catch (error) {
    console.error('구글 시트에서 리더를 가져오는 중 오류:', error)
    return []
  }
}

// REST API에서 데이터 가져오기
export const fetchEventsFromAPI = async (): Promise<Event[]> => {
  if (!API_BASE_URL) {
    console.warn('API Base URL이 설정되지 않았습니다.')
    return []
  }

  try {
    const response = await fetch(`${API_BASE_URL}/api/events`)
    if (!response.ok) {
      throw new Error('이벤트 데이터를 가져오는데 실패했습니다.')
    }
    const data = await response.json()
    return data.map((event: any) => ({
      ...event,
      date: new Date(event.date)
    })) as Event[]
  } catch (error) {
    console.error('API에서 이벤트를 가져오는 중 오류:', error)
    return []
  }
}

export const fetchLeadersFromAPI = async (): Promise<Leader[]> => {
  if (!API_BASE_URL) {
    console.warn('API Base URL이 설정되지 않았습니다.')
    return []
  }

  try {
    const response = await fetch(`${API_BASE_URL}/api/leaders`)
    if (!response.ok) {
      throw new Error('리더 데이터를 가져오는데 실패했습니다.')
    }
    return await response.json() as Leader[]
  } catch (error) {
    console.error('API에서 리더를 가져오는 중 오류:', error)
    return []
  }
}

// 데이터 소스 타입
export type DataSource = 'mock' | 'google-sheets' | 'api'

// 데이터 소스에 따라 적절한 함수 호출
export const fetchEvents = async (source: DataSource = 'mock'): Promise<Event[]> => {
  switch (source) {
    case 'google-sheets':
      return await fetchEventsFromGoogleSheets()
    case 'api':
      return await fetchEventsFromAPI()
    default:
      return []
  }
}

export const fetchLeaders = async (source: DataSource = 'mock'): Promise<Leader[]> => {
  switch (source) {
    case 'google-sheets':
      return await fetchLeadersFromGoogleSheets()
    case 'api':
      return await fetchLeadersFromAPI()
    default:
      return []
  }
}

