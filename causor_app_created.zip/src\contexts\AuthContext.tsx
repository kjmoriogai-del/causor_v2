import { createContext, useContext, useState, ReactNode, useMemo } from 'react'
import { User, UserRole } from '../types'
import { mockUser } from '../data/mockData'

interface AuthContextValue {
  currentUser: User
  isLeader: boolean
  switchRole: (role: UserRole) => void
  setCurrentUser: (user: User) => void
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<User>(mockUser)

  const switchRole = (role: UserRole) => {
    setCurrentUser((prev) => ({ ...prev, role }))
  }

  const value = useMemo(
    () => ({
      currentUser,
      isLeader: currentUser.role === 'leader',
      switchRole,
      setCurrentUser
    }),
    [currentUser]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

