import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { DataProvider } from './contexts/DataContext'
import Layout from './components/Layout'
import Home from './pages/Home'
import Leaders from './pages/Leaders'
import PairWeek from './pages/PairWeek'
import Calendar from './pages/Calendar'
import Profile from './pages/Profile'
import Admin from './pages/Admin'
import LeaderRoute from './components/LeaderRoute'
import { AuthProvider } from './contexts/AuthContext'

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <Router>
          <Layout>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/leaders" element={<Leaders />} />
              <Route path="/pair-week" element={<PairWeek />} />
              <Route path="/calendar" element={<Calendar />} />
              <Route path="/profile" element={<Profile />} />
              <Route
                path="/admin"
                element={
                  <LeaderRoute>
                    <Admin />
                  </LeaderRoute>
                }
              />
            </Routes>
          </Layout>
        </Router>
      </DataProvider>
    </AuthProvider>
  )
}

export default App

