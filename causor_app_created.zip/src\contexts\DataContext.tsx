import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react'
import { Event, Leader } from '../types'
import { mockEvents, mockLeaders } from '../data/mockData'
import { fetchEvents, fetchLeaders, DataSource } from '../services/api'

interface DataContextType {
  events: Event[]
  leaders: Leader[]
  setEvents: (events: Event[]) => void
  setLeaders: (leaders: Leader[]) => void
  updateEvent: (id: string, eventData: Partial<Event>) => void
  addEvent: (event: Event) => void
  deleteEvent: (id: string) => void
  updateLeader: (id: string, leaderData: Partial<Leader>) => void
  addLeader: (leader: Leader) => void
  deleteLeader: (id: string) => void
  refreshData: () => Promise<void>
  isLoading: boolean
}

const DataContext = createContext<DataContextType | undefined>(undefined)

// localStorage 키
const STORAGE_KEYS = {
  EVENTS: 'student-connection-app-events',
  LEADERS: 'student-connection-app-leaders'
}

// localStorage에서 데이터 로드
const loadFromStorage = <T,>(key: string, defaultValue: T): T => {
  try {
    const stored = localStorage.getItem(key)
    if (stored) {
      const parsed = JSON.parse(stored)
      // Date 객체 복원
      if (Array.isArray(parsed)) {
        return parsed.map((item: any) => {
          if (item.date) {
            return { ...item, date: new Date(item.date) }
          }
          return item
        }) as T
      }
      return parsed
    }
  } catch (error) {
    console.error(`localStorage에서 ${key} 로드 중 오류:`, error)
  }
  return defaultValue
}

// localStorage에 데이터 저장
const saveToStorage = <T,>(key: string, data: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data))
  } catch (error) {
    console.error(`localStorage에 ${key} 저장 중 오류:`, error)
  }
}

export const DataProvider = ({ children }: { children: ReactNode }) => {
  // localStorage에서 초기 데이터 로드 (없으면 mock 데이터 사용)
  const [events, setEventsState] = useState<Event[]>(() => 
    loadFromStorage(STORAGE_KEYS.EVENTS, mockEvents)
  )
  const [leaders, setLeadersState] = useState<Leader[]>(() => 
    loadFromStorage(STORAGE_KEYS.LEADERS, mockLeaders)
  )
  const [isLoading, setIsLoading] = useState(false)

  // events 변경 시 localStorage에 저장
  const setEvents = useCallback((newEvents: Event[]) => {
    setEventsState(newEvents)
    saveToStorage(STORAGE_KEYS.EVENTS, newEvents)
  }, [])

  // leaders 변경 시 localStorage에 저장
  const setLeaders = useCallback((newLeaders: Leader[]) => {
    setLeadersState(newLeaders)
    saveToStorage(STORAGE_KEYS.LEADERS, newLeaders)
  }, [])

  // 데이터 소스 설정 (환경 변수 또는 기본값)
  const dataSource: DataSource = (import.meta.env.VITE_DATA_SOURCE as DataSource) || 'mock'

  // API에서 데이터 가져오기
  const loadData = useCallback(async () => {
    if (dataSource === 'mock') {
      // localStorage에 저장된 데이터가 있으면 사용, 없으면 mock 데이터 사용
      const storedEvents = loadFromStorage(STORAGE_KEYS.EVENTS, mockEvents)
      const storedLeaders = loadFromStorage(STORAGE_KEYS.LEADERS, mockLeaders)
      setEvents(storedEvents)
      setLeaders(storedLeaders)
      return
    }

    setIsLoading(true)
    try {
      const [fetchedEvents, fetchedLeaders] = await Promise.all([
        fetchEvents(dataSource),
        fetchLeaders(dataSource)
      ])

      // API에서 데이터를 가져온 경우에만 업데이트
      if (fetchedEvents.length > 0) {
        setEvents(fetchedEvents)
      }
      if (fetchedLeaders.length > 0) {
        setLeaders(fetchedLeaders)
      }
    } catch (error) {
      console.error('데이터 로드 중 오류:', error)
      // 오류 발생 시 localStorage 또는 mock 데이터 사용
      const storedEvents = loadFromStorage(STORAGE_KEYS.EVENTS, mockEvents)
      const storedLeaders = loadFromStorage(STORAGE_KEYS.LEADERS, mockLeaders)
      setEvents(storedEvents)
      setLeaders(storedLeaders)
    } finally {
      setIsLoading(false)
    }
  }, [dataSource, setEvents, setLeaders])

  // 컴포넌트 마운트 시 데이터 로드
  useEffect(() => {
    loadData()
  }, [loadData])

  const updateEvent = useCallback((id: string, eventData: Partial<Event>) => {
    const updatedEvents = events.map(e => e.id === id ? { ...e, ...eventData } as Event : e)
    setEvents(updatedEvents)
  }, [events, setEvents])

  const addEvent = useCallback((event: Event) => {
    const updatedEvents = [...events, event]
    setEvents(updatedEvents)
  }, [events, setEvents])

  const deleteEvent = useCallback((id: string) => {
    const updatedEvents = events.filter(e => e.id !== id)
    setEvents(updatedEvents)
  }, [events, setEvents])

  const updateLeader = useCallback((id: string, leaderData: Partial<Leader>) => {
    const updatedLeaders = leaders.map(l => l.id === id ? { ...l, ...leaderData } as Leader : l)
    setLeaders(updatedLeaders)
  }, [leaders, setLeaders])

  const addLeader = useCallback((leader: Leader) => {
    const updatedLeaders = [...leaders, leader]
    setLeaders(updatedLeaders)
  }, [leaders, setLeaders])

  const deleteLeader = useCallback((id: string) => {
    const updatedLeaders = leaders.filter(l => l.id !== id)
    setLeaders(updatedLeaders)
  }, [leaders, setLeaders])

  const refreshData = async () => {
    await loadData()
  }

  return (
    <DataContext.Provider
      value={{
        events,
        leaders,
        setEvents,
        setLeaders,
        updateEvent,
        addEvent,
        deleteEvent,
        updateLeader,
        addLeader,
        deleteLeader,
        refreshData,
        isLoading,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export const useData = () => {
  const context = useContext(DataContext)
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider')
  }
  return context
}

