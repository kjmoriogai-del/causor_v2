import { Leader, Event, User } from '../types'

export const mockLeaders: Leader[] = [
  {
    id: '1',
    name: '김민수',
    age: 23,
    nationality: 'korean',
    photo: 'https://api.dicebear.com/7.x/avataaars/svg?seed=kim',
    shortDescription: '한국 문화를 사랑하는 친절한 리더',
    detailedDescription: '안녕하세요! 한국 문화를 전 세계 친구들에게 소개하는 것을 좋아합니다. 함께 맛있는 음식을 먹고 이야기 나누는 것을 즐깁니다.',
    hobbies: ['요리', '여행', '사진 촬영'],
    strengths: ['친절함', '소통 능력', '문화 이해'],
    eventsHosted: 12,
    recentActivity: true
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    age: 22,
    nationality: 'international',
    photo: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sarah',
    shortDescription: '한국어를 배우고 싶은 유학생 리더',
    detailedDescription: 'Hello! I love learning Korean and making friends. I enjoy language exchange and cultural activities.',
    hobbies: ['Language Learning', 'Hiking', 'Reading'],
    strengths: ['Open-minded', 'Enthusiastic', 'Cultural Bridge'],
    eventsHosted: 8,
    recentActivity: true
  },
  {
    id: '3',
    name: '이지은',
    age: 24,
    nationality: 'korean',
    photo: 'https://api.dicebear.com/7.x/avataaars/svg?seed=lee',
    shortDescription: '글로벌 네트워크 형성을 추구하는 리더',
    detailedDescription: '다양한 문화를 가진 친구들과 함께 성장하는 것을 좋아합니다. 정기적인 모임을 통해 깊은 관계를 형성하고 있습니다.',
    hobbies: ['독서', '영화 감상', '요가'],
    strengths: ['조직력', '공감 능력', '리더십'],
    eventsHosted: 15
  },
  {
    id: '4',
    name: 'James Park',
    age: 21,
    nationality: 'international',
    photo: 'https://api.dicebear.com/7.x/avataaars/svg?seed=james',
    shortDescription: '한국 대학 생활을 즐기는 유학생',
    detailedDescription: 'I\'m passionate about Korean culture and love organizing study groups and food tours!',
    hobbies: ['Photography', 'Cooking', 'Sports'],
    strengths: ['Creativity', 'Teamwork', 'Adaptability'],
    eventsHosted: 6
  }
]

// 현재 날짜 기준으로 이벤트 날짜 생성 (오늘 이후 날짜로 설정)
const now = new Date()
const currentYear = now.getFullYear()
const currentMonth = now.getMonth()
const currentDate = now.getDate()

// 오늘이 15일 이후면 다음 달로, 아니면 이번 달로 설정
const getEventDate = (day: number) => {
  if (day < currentDate && currentDate > 20) {
    // 이번 달이 거의 끝나면 다음 달로
    return new Date(currentYear, currentMonth + 1, day)
  }
  return new Date(currentYear, currentMonth, Math.max(day, currentDate + 1))
}

export const mockEvents: Event[] = [
  {
    id: '1',
    title: '한식 맛집 투어',
    description: '서울의 유명한 한식 맛집을 함께 탐방하며 한국 음식 문화를 체험해봐요!',
    date: getEventDate(15),
    time: '18:00',
    location: '강남역',
    type: 'meal',
    leaderId: '1',
    leaderName: '김민수',
    participants: 8,
    maxParticipants: 12,
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800'
  },
  {
    id: '2',
    title: '한국어 스터디 그룹',
    description: '함께 한국어를 배우고 연습하는 스터디 그룹입니다. 초급부터 고급까지 환영합니다!',
    date: getEventDate(16),
    time: '14:00',
    location: '학교 도서관',
    type: 'study',
    leaderId: '2',
    leaderName: 'Sarah Johnson',
    participants: 5,
    maxParticipants: 10,
    image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=800'
  },
  {
    id: '3',
    title: '멘토링 세션',
    description: '한국 대학 생활에 대한 조언과 정보를 공유하는 멘토링 시간입니다.',
    date: getEventDate(17),
    time: '16:00',
    location: '카페',
    type: 'mentoring',
    leaderId: '3',
    leaderName: '이지은',
    participants: 3,
    maxParticipants: 5
  },
  {
    id: '4',
    title: '주말 하이킹',
    description: '서울 근교 산을 함께 등반하며 자연을 즐기고 친구들과 소통하는 시간입니다.',
    date: getEventDate(20),
    time: '09:00',
    location: '북한산',
    type: 'activity',
    leaderId: '4',
    leaderName: 'James Park',
    participants: 6,
    maxParticipants: 10,
    image: 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=800'
  },
  {
    id: '5',
    title: '저녁 식사 모임',
    description: '편안한 분위기에서 저녁을 함께 먹으며 서로를 알아가는 시간입니다.',
    date: getEventDate(18),
    time: '19:00',
    location: '홍대',
    type: 'meal',
    leaderId: '1',
    leaderName: '김민수',
    participants: 4,
    maxParticipants: 8
  },
  {
    id: '6',
    title: '문화 교류 모임',
    description: '각자의 문화를 소개하고 경험을 공유하는 문화 교류 모임입니다.',
    date: new Date(currentYear, currentMonth + 1, 5),
    time: '15:00',
    location: '학교 교실',
    type: 'activity',
    leaderId: '3',
    leaderName: '이지은',
    participants: 0,
    maxParticipants: 15
  }
]

export const mockUser: User = {
  id: 'user1',
  name: '홍길동',
  nickname: '길동이',
  shortDescription: '유학생 친구들과 함께 성장하고 싶은 대학생입니다.',
  photo: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user',
  hostedEvents: [],
  participatedEvents: [mockEvents[0], mockEvents[2]],
  role: 'general'
}

