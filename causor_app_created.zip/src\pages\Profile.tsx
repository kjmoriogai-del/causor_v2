import { mockUser, mockEvents } from '../data/mockData'
import { format } from 'date-fns'
import ko from 'date-fns/locale/ko'
import './Profile.css'

const Profile = () => {
  const user = mockUser

  const eventTypes = {
    meal: '🍽️',
    mentoring: '👥',
    study: '📚',
    activity: '🎯',
    other: '📌'
  }

  return (
    <div className="profile-page">
      <div className="profile-header">
        <div className="profile-photo-container">
          {user.photo ? (
            <img src={user.photo} alt={user.name} className="profile-photo" />
          ) : (
            <div className="profile-photo-placeholder">
              {user.name.charAt(0)}
            </div>
          )}
        </div>
        <div className="profile-info">
          <h2>{user.name}</h2>
          <p className="profile-nickname">@{user.nickname}</p>
          <p className="profile-description">{user.shortDescription}</p>
        </div>
      </div>

      <div className="profile-stats">
        <div className="stat-item">
          <div className="stat-number">{user.hostedEvents.length}</div>
          <div className="stat-label">진행한 이벤트</div>
        </div>
        <div className="stat-item">
          <div className="stat-number">{user.participatedEvents.length}</div>
          <div className="stat-label">참가한 이벤트</div>
        </div>
      </div>

      <div className="profile-sections">
        {user.hostedEvents.length > 0 && (
          <section className="profile-section">
            <h3 className="section-title">
              <span>📅</span> 진행한 이벤트
            </h3>
            <div className="events-list">
              {user.hostedEvents.map(event => (
                <div key={event.id} className="event-item">
                  <div className="event-icon">{eventTypes[event.type]}</div>
                  <div className="event-content">
                    <h4>{event.title}</h4>
                    <p className="event-date">
                      {format(event.date, 'yyyy년 M월 d일', { locale: ko })}
                    </p>
                    <p className="event-description">{event.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {user.participatedEvents.length > 0 && (
          <section className="profile-section">
            <h3 className="section-title">
              <span>✅</span> 참가한 이벤트
            </h3>
            <div className="events-list">
              {user.participatedEvents.map(event => (
                <div key={event.id} className="event-item">
                  <div className="event-icon">{eventTypes[event.type]}</div>
                  <div className="event-content">
                    <h4>{event.title}</h4>
                    <p className="event-meta">
                      <span className="event-date">
                        {format(event.date, 'yyyy년 M월 d일', { locale: ko })}
                      </span>
                      <span className="event-leader">리더: {event.leaderName}</span>
                    </p>
                    <p className="event-description">{event.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {user.hostedEvents.length === 0 && user.participatedEvents.length === 0 && (
          <div className="empty-state">
            <p>아직 진행하거나 참가한 이벤트가 없습니다.</p>
            <p>다양한 이벤트에 참여해보세요!</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default Profile

