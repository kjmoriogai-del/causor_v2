import { useState } from 'react'
import { useData } from '../contexts/DataContext'
import { Leader } from '../types'
import './Leaders.css'

const Leaders = () => {
  const { leaders } = useData()
  const [selectedLeader, setSelectedLeader] = useState<Leader | null>(null)
  const [filter, setFilter] = useState<'all' | 'korean' | 'international'>('all')

  const recentLeaders = leaders.filter(l => l.recentActivity)
  const activeLeaders = leaders.filter(l => l.eventsHosted > 0 && !l.recentActivity)
  const filteredLeaders = filter === 'all' 
    ? leaders 
    : leaders.filter(l => l.nationality === filter)

  return (
    <div className="leaders-page">
      <div className="page-header">
        <h2>운영 리더 소개</h2>
        <p>한국인과 유학생 리더들이 함께 운영하는 커뮤니티입니다</p>
      </div>

      <div className="filter-buttons">
        <button 
          className={filter === 'all' ? 'active' : ''}
          onClick={() => setFilter('all')}
        >
          전체
        </button>
        <button 
          className={filter === 'korean' ? 'active' : ''}
          onClick={() => setFilter('korean')}
        >
          한국인 리더
        </button>
        <button 
          className={filter === 'international' ? 'active' : ''}
          onClick={() => setFilter('international')}
        >
          유학생 리더
        </button>
      </div>

      {filter === 'all' && (
        <>
          {recentLeaders.length > 0 && (
            <section className="leader-section">
              <h3 className="section-title">✨ 최근 활동 리더</h3>
              <div className="leaders-grid">
                {recentLeaders.map(leader => (
                  <LeaderCard 
                    key={leader.id} 
                    leader={leader} 
                    onClick={() => setSelectedLeader(leader)}
                  />
                ))}
              </div>
            </section>
          )}

          {activeLeaders.length > 0 && (
            <section className="leader-section">
              <h3 className="section-title">📅 이번 달 행사 진행 리더</h3>
              <div className="leaders-grid">
                {activeLeaders.map(leader => (
                  <LeaderCard 
                    key={leader.id} 
                    leader={leader} 
                    onClick={() => setSelectedLeader(leader)}
                  />
                ))}
              </div>
            </section>
          )}
        </>
      )}

      <section className="leader-section">
        <h3 className="section-title">
          {filter === 'all' ? '👥 전체 리더' : filter === 'korean' ? '🇰🇷 한국인 리더' : '🌍 유학생 리더'}
        </h3>
        <div className="leaders-grid">
          {filteredLeaders.map(leader => (
            <LeaderCard 
              key={leader.id} 
              leader={leader} 
              onClick={() => setSelectedLeader(leader)}
            />
          ))}
        </div>
      </section>

      {selectedLeader && (
        <LeaderModal 
          leader={selectedLeader} 
          onClose={() => setSelectedLeader(null)}
        />
      )}
    </div>
  )
}

interface LeaderCardProps {
  leader: Leader
  onClick: () => void
}

const LeaderCard = ({ leader, onClick }: LeaderCardProps) => {
  return (
    <div className="leader-card" onClick={onClick}>
      <div className="leader-photo-container">
        <img src={leader.photo} alt={leader.name} className="leader-photo" />
        {leader.recentActivity && <span className="badge new">NEW</span>}
      </div>
      <div className="leader-info">
        <h4>{leader.name}</h4>
        <p className="leader-short-desc">{leader.shortDescription}</p>
        <div className="leader-stats">
          <span>📊 행사 {leader.eventsHosted}개 진행</span>
        </div>
      </div>
    </div>
  )
}

interface LeaderModalProps {
  leader: Leader
  onClose: () => void
}

const LeaderModal = ({ leader, onClose }: LeaderModalProps) => {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>×</button>
        <div className="modal-header">
          <img src={leader.photo} alt={leader.name} className="modal-photo" />
          <div>
            <h2>{leader.name}</h2>
            <p className="modal-age">{leader.age}세</p>
            <p className="modal-nationality">
              {leader.nationality === 'korean' ? '🇰🇷 한국인' : '🌍 유학생'}
            </p>
          </div>
        </div>
        <div className="modal-body">
          <section>
            <h3>소개</h3>
            <p>{leader.detailedDescription}</p>
          </section>
          <section>
            <h3>취미</h3>
            <div className="tags">
              {leader.hobbies.map((hobby, index) => (
                <span key={index} className="tag">{hobby}</span>
              ))}
            </div>
          </section>
          <section>
            <h3>장점</h3>
            <div className="tags">
              {leader.strengths.map((strength, index) => (
                <span key={index} className="tag">{strength}</span>
              ))}
            </div>
          </section>
          <section>
            <h3>활동 통계</h3>
            <p>진행한 행사: {leader.eventsHosted}개</p>
          </section>
        </div>
      </div>
    </div>
  )
}

export default Leaders

