import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useData } from '../contexts/DataContext'
import { format } from 'date-fns'
import ko from 'date-fns/locale/ko'
import './Home.css'

const Home = () => {
  const { events } = useData()
  const [currentBanner, setCurrentBanner] = useState(0)
  
  // 이번 달과 다음 달 이벤트 필터링
  const now = new Date()
  now.setHours(0, 0, 0, 0) // 시간을 00:00:00으로 설정하여 날짜만 비교
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 2, 1) // 다음 달까지 포함
  
  const upcomingEvents = events
    .filter(event => {
      const eventDate = new Date(event.date)
      eventDate.setHours(0, 0, 0, 0)
      return eventDate >= now && eventDate < nextMonth
    })
    .slice(0, 3)

  const nextSlide = () => {
    setCurrentBanner((prev) => (prev + 1) % upcomingEvents.length)
  }

  const prevSlide = () => {
    setCurrentBanner((prev) => (prev - 1 + upcomingEvents.length) % upcomingEvents.length)
  }

  if (upcomingEvents.length === 0) {
    return (
      <div className="home">
        <div className="welcome-section">
          <h2>환영합니다!</h2>
          <p>곧 새로운 이벤트가 등록될 예정입니다.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="home">
      <div className="welcome-section">
        <h2>이번 달 예정된 이벤트</h2>
        <p>유학생과 재학생이 함께하는 다양한 활동에 참여해보세요!</p>
      </div>

      <div className="banner-container">
        <button className="banner-nav prev" onClick={prevSlide}>‹</button>
        <div className="banner-wrapper">
          {upcomingEvents.map((event, index) => (
            <div
              key={event.id}
              className={`banner ${index === currentBanner ? 'active' : ''}`}
            >
              {event.image && (
                <img src={event.image} alt={event.title} className="banner-image" />
              )}
              <div className="banner-content">
                <h3>{event.title}</h3>
                <p>{event.description}</p>
                <div className="banner-info">
                  <span>📅 {format(event.date, 'yyyy년 M월 d일 (EEE)', { locale: ko })}</span>
                  <span>🕐 {event.time}</span>
                  <span>📍 {event.location}</span>
                </div>
                <Link to={`/calendar?event=${event.id}`} className="banner-button">
                  자세히 보기
                </Link>
              </div>
            </div>
          ))}
        </div>
        <button className="banner-nav next" onClick={nextSlide}>›</button>
      </div>

      <div className="banner-indicators">
        {upcomingEvents.map((_, index) => (
          <button
            key={index}
            className={`indicator ${index === currentBanner ? 'active' : ''}`}
            onClick={() => setCurrentBanner(index)}
          />
        ))}
      </div>

      <div className="quick-links">
        <Link to="/leaders" className="quick-link">
          <h3>리더 소개</h3>
          <p>운영 리더들의 정보를 확인하세요</p>
        </Link>
        <Link to="/pair-week" className="quick-link">
          <h3>Pair Week</h3>
          <p>이번 주 소규모 행사 정보</p>
        </Link>
        <Link to="/calendar" className="quick-link">
          <h3>캘린더</h3>
          <p>전체 이벤트 일정 확인</p>
        </Link>
      </div>
    </div>
  )
}

export default Home

