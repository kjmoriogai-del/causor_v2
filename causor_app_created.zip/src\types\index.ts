export interface Leader {
  id: string
  name: string
  age: number
  nationality: 'korean' | 'international'
  photo: string
  shortDescription: string
  detailedDescription: string
  hobbies: string[]
  strengths: string[]
  eventsHosted: number
  recentActivity?: boolean
}

export interface Event {
  id: string
  title: string
  description: string
  date: Date
  time: string
  location: string
  type: 'meal' | 'mentoring' | 'study' | 'activity' | 'other'
  leaderId: string
  leaderName: string
  participants: number
  maxParticipants?: number
  image?: string
}

export type UserRole = 'leader' | 'general'

export interface User {
  id: string
  name: string
  nickname: string
  shortDescription: string
  hostedEvents: Event[]
  participatedEvents: Event[]
  photo?: string
  role: UserRole
}

